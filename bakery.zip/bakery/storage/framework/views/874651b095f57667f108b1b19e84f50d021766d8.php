<?php $__env->startSection('page_header'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Dashboard</h5>
                        <p class="m-b-0">Welcome to Canada Bakery</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item"><a href="javascript:;">Assigned Bread to Resturants</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>
                        <?php $sheet = DB::table('sheets')->where('id',Request::segment(2))->first(); ?>
                        Assigned Bread to Resturants ( <strong><?php echo e($sheet->name); ?></strong> )
                    </h5>
                    <div class="card-header-right">
                    </div>
                </div>
                <div class="card-block">
                    <table class="table table-condensed table-hover table-striped">
                        <thead>
                            <th style="width: 1%">#</th>
                            <th style="width: 10%">Resturant</th>
                            <th style="width: 35%">Bread Type</th>
                            <th style="width: 20%">Qty</th>
                            <th style="width: 20%">Status</th>
                            <th style="width: 10%">Action</th>

                        </thead>
                        <tbody>
                            <?php $id=1; ?>
                            <?php $__currentLoopData = $resturants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $res): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $assignedBreadsData = DB::table('assigned_breads')
                                        ->where('resturant_id', $res->id)
                                        ->where('sheet', Request::segment('2'))
                                        ->get();
                                    $assignedTypes = DB::table('assigned_breads_type')
                                        ->where('resturant_id', $res->id)
                                        ->where('sheet', Request::segment('2'))
                                        ->get();
                                ?>
                                <?php if(count($assignedBreadsData) > 0): ?>
                                    <tr>
                                        
                                        <form action="<?php echo e(route('assigned.breads.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="sheet" value="<?php echo e(Request::segment('2')); ?>">
                                            <input type="hidden" name="id" value="<?php echo e($assignedBreadsData[0]->id); ?>">
                                            <td><?php echo e($id++); ?></td>
                                            <td>
                                                <?php echo e($res->name); ?>

                                                <input type="hidden" name="resturant_id" value="<?php echo e($res->id); ?>">
                                            </td>
                                            <td>
                                                <div class="row">
                                                    <div class="co-lg-12 col-md-12">
                                                        <select name="bread_type[]" multiple style="width: 100%">
                                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->type); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>

                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <?php $__currentLoopData = $assignedTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assinedTypesData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php
                                                                $names = DB::table('bread_type')
                                                                    ->where('id', $assinedTypesData->type_id)
                                                                    ->get();
                                                            ?>
                                                            <span class="badge badge-success">
                                                                <?php echo e($names[0]->type); ?>

                                                                <a href="<?php echo e(route('assignedType.delete', ['id' => $assinedTypesData->id])); ?>"
                                                                    class="ti-trash text-bold text-white"></a>
                                                            </span>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </div>
                                                </div>




                                            </td>
                                            <td>
                                                <input style="width: 100% !important" type="number"
                                                    value="<?php echo e($assignedBreadsData[0]->qty); ?>" name="quantity"
                                                    class="form-control form-control-sm" placeholder="Qty">
                                            </td>
                                            <td>
                                                <?php if(@isset($assignedBreadsData[0]->status)): ?>
                                                    <span
                                                        class="badge <?php echo e($assignedBreadsData[0]->status == 0 ? 'badge-primary' : 'badge-success'); ?>  ">
                                                        <?php echo e($assignedBreadsData[0]->status == 0 ? 'Pending' : 'Done'); ?>

                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge badge-info ">
                                                        Pending
                                                    </span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <button type="submit" class="btn btn-sm btn-inverse btn-block">
                                                    Change
                                                </button>
                                            </td>
                                        </form>
                                        
                                    </tr>
                                <?php else: ?>
                                    <tr>
                                        
                                        <form action="<?php echo e(route('assigned.breads.store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="sheet" value="<?php echo e(Request::segment('2')); ?>">
                                            <td><?php echo e($id++); ?></td>
                                            <td>
                                                <?php echo e($res->name); ?>

                                                <input type="hidden" name="resturant_id" value="<?php echo e($res->id); ?>">
                                            </td>
                                            <td>
                                                <div class="row">
                                                    <div class="co-lg-12 col-md-12">
                                                        <select name="bread_type[]" multiple style="width: 100%">
                                                            <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($data->id); ?>"><?php echo e($data->type); ?>

                                                                </option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>

                                                    </div>
                                                </div>




                                            </td>
                                            <td>
                                                <input type="number" name="quantity" class="form-control form-control-sm"
                                                    placeholder="Qty">
                                            </td>
                                            <td>
                                                <span class="badge badge-info ">
                                                    Pending
                                                </span>
                                            </td>
                                            <td>
                                                <button type="submit" class="btn btn-sm btn-success btn-block">
                                                    Submit
                                                </button>
                                            </td>
                                        </form>
                                        
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>


    <?php echo $__env->make('resturants.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_baker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xammp\htdocs\Canada\bakery\resources\views/assigned_bread/baker_create.blade.php ENDPATH**/ ?>