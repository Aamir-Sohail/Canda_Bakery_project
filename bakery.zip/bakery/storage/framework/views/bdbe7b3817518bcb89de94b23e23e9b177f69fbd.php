<style>
    .pcoded .pcoded-navbar .pcoded-item:after {
        content: "";
        background-color: #e4e9eb;
        width: 0%;
        height: 1px;
        position: absolute;
        left: 10%;
        bottom: 10px;
    }

</style>
<nav class="pcoded-navbar">
    <div class="sidebar_toggle"><a href="#"><i class="icon-close icons"></i></a></div>
    <div class="pcoded-inner-navbar main-menu">
        <div class="">
            <div class="main-menu-header">
                <img class="img-80 img-radius" src="<?php echo e(asset('user.png')); ?>" alt="User-Profile-Image">
                <div class="user-details">
                    <span id="more-details"><?php echo e(\Auth::user()->name); ?><i class="fa fa-caret-down"></i></span>
                </div>
            </div>

            <div class="main-menu-content">
                <ul>
                    <li class="more-details">

                        <a href="#!"><i class="ti-settings"></i>Settings</a>
                        <a href="<?php echo e(route('logout')); ?>"><i class="ti-layout-sidebar-left"></i>Logout</a>
                    </li>
                </ul>
            </div>
        </div>



        <ul class="pcoded-item pcoded-left-item" style="margin-top: 3%">
            <li class="<?php if(Route::currentRouteName()=='dashboard' ): ?> active <?php endif; ?>">
                <a href="<?php echo e(route('dashboard')); ?>" class="waves-effect waves-dark">
                    <span class="pcoded-micon"><i class="ti-desktop"></i><b>D</b></span>
                    <span class="pcoded-mtext" data-i18n="nav.dash.main">Dashboard</span>
                    <span class="pcoded-mcaret"></span>
                </a>
            </li>


            <ul class="pcoded-item pcoded-left-item" style="border: none">
                <li class="<?php if(Route::currentRouteName()=='resturants' ): ?> active <?php endif; ?>" style="border: none !important">
                    <a href="<?php echo e(route('resturants')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="ti-desktop"></i><b>RS</b></span>
                        <span class="pcoded-mtext" data-i18n="nav.form-components.main">Resturants</span>
                        <span class="pcoded-mcaret"></span>
                    </a>
                </li>
                <li class="<?php if(Route::currentRouteName()=='bakers' ): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('bakers')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="ti-user"></i><b>BK</b></span>
                        <span class="pcoded-mtext" data-i18n="nav.form-components.main">Bakers</span>
                    </a>
                </li>
                <li class="<?php if(Route::currentRouteName()=='bread.types' ): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('bread.types')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="ti-layers-alt"></i><b>BT</b></span>
                        <span class="pcoded-mtext" data-i18n="nav.form-components.main">Bread Type</span>
                    </a>
                </li>
                <li class="<?php if(Route::currentRouteName()=='sheets' ): ?> active <?php endif; ?>">
                    <a href="<?php echo e(route('sheets')); ?>" class="waves-effect waves-dark">
                        <span class="pcoded-micon"><i class="ti-layers-alt"></i><b>BT</b></span>
                        <span class="pcoded-mtext" data-i18n="nav.form-components.main">Sheets</span>
                    </a>
                </li>
            </ul>


        </ul>
    </div>
</nav>
<?php /**PATH /Users/shahnawazmiakhel/Documents/Development/Fiverr/laravel/Canada/bakery/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>