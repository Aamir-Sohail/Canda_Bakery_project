<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-ui/jquery-ui.min.js ')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/popper.js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/pages/waves/js/waves.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery-slimscroll/jquery.slimscroll.js ')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/SmoothScroll.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js ')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pcoded.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/vertical-layout.min.js ')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
<?php /**PATH /Users/shahnawazmiakhel/Documents/Development/Fiverr/laravel/Canada/bakery/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>