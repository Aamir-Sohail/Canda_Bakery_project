<?php $__env->startSection('page_header'); ?>
    <div class="page-header">
        <div class="page-block">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <div class="page-header-title">
                        <h5 class="m-b-10">Dashboard</h5>
                        <p class="m-b-0">Welcome to Canada Bakery</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <ul class="breadcrumb-title">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('dashboard')); ?>"> <i class="fa fa-home"></i> </a>
                        </li>
                        <li class="breadcrumb-item"><a href="javascript:;">Bakers</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-xl-12 col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5>
                        Bakers
                    </h5>


                    <div class="card-header-right">

                        <button type="button" data-toggle="modal" data-target="#exampleModal"
                            class="btn waves-effect btn-sm waves-light btn-inverse btn-outline-inverse"
                            style="margin-top: -10% !important">
                            <i class="ti-plus text-bold text-black"
                                style="font-weight: bold !important; font-size:12px !important"></i>Add New Baker
                        </button>
                    </div>
                </div>
                <div class="card-block">
                    <table class="table table-condensed table-hover table-striped">
                        <thead>
                            <th style="width: 5%">#</th>
                            <th style="width: 30%">Name</th>
                            <th style="width: 30%">Email</th>
                            <th style="width: 15%">Role</th>
                            <th style="width: 10%">Action</th>
                        </thead>
                        <tbody>
                            <?php $id=1; ?>
                            <?php $__currentLoopData = $bakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($id++); ?></td>
                                    <td>
                                        <?php echo e($data->name); ?>

                                    </td>
                                    <td>
                                        <?php echo e($data->email); ?>

                                    </td>
                                    <td>
                                        <span class="badge badge-inverse">
                                            <?php echo e($data->type == 'admin' ? 'Admin' : 'Baker'); ?>

                                        </span>
                                    </td>

                                    <td>
                                        <a onclick="return confirm('Are u sure')"
                                            href="<?php echo e(route('bakers.delete', ['id' => $data->id])); ?>"
                                            class="btn btn-sm btn-danger btn-skew btn-mat">
                                            <span class="ti-trash"></span> Delete
                                        </a>
                                        <button type="button" data-toggle="modal"
                                            data-target="#breadModalEdit<?php echo e($data->id); ?>"
                                            class="btn btn-primary btn-sm btn-skew btn-mat">
                                            <span class="ti-pencil-alt"></span> Edit
                                        </button>
                                        <?php echo $__env->make('bakers.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('bakers.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xammp\htdocs\Canada\bakery\resources\views/bakers/index.blade.php ENDPATH**/ ?>